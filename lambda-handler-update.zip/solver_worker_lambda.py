"""
AWS Lambda Worker - SQS Message Processor
==========================================

This Lambda processes solver tasks from SQS queue.
Triggered by SQS events, runs the real solver without timeout pressure.

Environment Variables:
    S3_RESULTS_BUCKET: S3 bucket for results
    AWS_REGION: AWS region
"""

import json
import logging
import os
import tempfile
import boto3
import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional

logger = logging.getLogger("aws-lambda-solver-worker")
logger.setLevel(logging.INFO)

# AWS Configuration
S3_BUCKET = os.environ.get('S3_RESULTS_BUCKET', 'scheduling-solver-results')
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')

# Initialize AWS clients
s3_client = boto3.client('s3', region_name=AWS_REGION)
dynamodb = boto3.resource('dynamodb', region_name=AWS_REGION)

# Try to import the real solver
try:
    import solver_core_real
except ImportError:
    logger.error("Could not import solver_core_real - solver will fail")
    solver_core_real = None


def get_next_result_number() -> int:
    """Get next available result_N number from S3"""
    try:
        response = s3_client.list_objects_v2(
            Bucket=S3_BUCKET,
            Delimiter='/'
        )
        
        prefixes = response.get('CommonPrefixes', [])
        if not prefixes:
            return 1
        
        # Extract numbers from result_N folders
        numbers = []
        for prefix in prefixes:
            folder_name = prefix['Prefix'].rstrip('/')
            if folder_name.startswith('result_'):
                try:
                    num = int(folder_name.replace('result_', ''))
                    numbers.append(num)
                except ValueError:
                    pass
        
        return max(numbers) + 1 if numbers else 1
    except Exception as e:
        logger.error(f"[ERROR] Error getting next result number: {e}")
        return int(datetime.utcnow().timestamp())


def upload_results_to_s3(run_id: str, tables: List[Dict], metadata: Dict[str, Any]) -> str:
    """Upload solver results to S3"""
    
    try:
        # Get next folder number
        result_num = get_next_result_number()
        folder_name = f"result_{result_num}"
        
        # Prepare metadata
        metadata_to_store = {
            "run_id": run_id,
            "created_at": datetime.utcnow().isoformat(),
            "solver_type": "aws_lambda",
            "solutions_count": len(tables),
            "phase2": metadata.get('phase2', {}),
            "per_table": metadata.get('per_table', [])
        }
        
        # Upload metadata
        metadata_key = f"{folder_name}/metadata.json"
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=metadata_key,
            Body=json.dumps(metadata_to_store, indent=2),
            ContentType='application/json'
        )
        
        # Upload calendars (from first table)
        if tables and 'calendar' in tables[0]:
            calendars_key = f"{folder_name}/calendars.json"
            s3_client.put_object(
                Bucket=S3_BUCKET,
                Key=calendars_key,
                Body=json.dumps({"calendar": tables[0]['calendar']}, indent=2),
                ContentType='application/json'
            )
        
        # Upload schedules for each solution
        schedules = []
        for i, table in enumerate(tables):
            schedules.append({
                "solution": i + 1,
                "shifts": table.get('shifts', []),
                "assignments": table.get('assignment', [])
            })
        
        schedules_key = f"{folder_name}/schedules.json"
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=schedules_key,
            Body=json.dumps({"schedules": schedules}, indent=2),
            ContentType='application/json'
        )
        
        # Upload provider assignments
        assignments = []
        for i, table in enumerate(tables):
            for s_idx, p_idx in table.get('assignment', []):
                shift = table['shifts'][s_idx]
                provider = table['providers'][p_idx]
                assignments.append({
                    "solution": i + 1,
                    "shift_id": shift.get('id', ''),
                    "provider_name": provider.get('name', ''),
                    "date": shift.get('date', ''),
                    "shift_type": shift.get('type', ''),
                    "start_time": shift.get('start', ''),
                    "end_time": shift.get('end', '')
                })
        
        assignments_key = f"{folder_name}/hospital_assignments.json"
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=assignments_key,
            Body=json.dumps({"assignments": assignments}, indent=2),
            ContentType='application/json'
        )
        
        logger.info(f"[S3] Uploaded results to {folder_name}")
        return folder_name
        
    except Exception as e:
        logger.error(f"[ERROR] Error uploading to S3: {e}")
        raise


def process_solver_task(run_id: str, case_data: Dict[str, Any]) -> tuple:
    """Process solver task and return tables and metadata"""
    
    logger.info(f"[WORKER] Processing run {run_id}")
    
    if not solver_core_real:
        raise RuntimeError("Solver module not available")
    
    # Save case to temp file
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.json') as tmp:
        json.dump(case_data, tmp)
        tmp_path = tmp.name
    
    try:
        # Run the solver
        logger.info(f"[SOLVER] Starting optimization...")
        tables, meta = solver_core_real.Solve_test_case_lambda(tmp_path)
        
        logger.info(f"[SOLVER] Optimization complete. Generated {len(tables)} solutions")
        
        return tables, meta
        
    finally:
        # Clean up temp file
        try:
            os.unlink(tmp_path)
        except:
            pass


def lambda_handler(event, context):
    """
    Main SQS event handler
    
    Receives messages from SQS queue and processes solver tasks
    """
    
    logger.info(f"[HANDLER] Processing {len(event['Records'])} SQS messages")
    
    for record in event['Records']:
        try:
            message_body = json.loads(record['body'])
            run_id = message_body['run_id']
            case_data = message_body['case']
            
            logger.info(f"[MESSAGE] Processing run {run_id}")
            
            # Process the solver task
            try:
                tables, meta = process_solver_task(run_id, case_data)
                
                # Upload results
                folder_name = upload_results_to_s3(run_id, tables, meta)
                
                logger.info(f"[SUCCESS] Run {run_id} completed: {folder_name}")
                
            except Exception as solver_error:
                logger.error(f"[SOLVER ERROR] Run {run_id}: {type(solver_error).__name__}: {solver_error}")
                import traceback
                logger.error(f"[TRACEBACK]\n{traceback.format_exc()}")
                raise
            
        except Exception as e:
            logger.error(f"[ERROR] Processing message failed: {e}")
            import traceback
            logger.error(f"[TRACEBACK]\n{traceback.format_exc()}")
            # Don't re-raise - let SQS handle retry logic
            continue
    
    return {"statusCode": 200, "body": "Processed"}


# For testing locally
if __name__ == "__main__":
    # Test event
    test_event = {
        "Records": [
            {
                "body": json.dumps({
                    "run_id": "test-run-123",
                    "case": {"test": "data"}
                })
            }
        ]
    }
    
    class MockContext:
        pass
    
    result = lambda_handler(test_event, MockContext())
    print(f"Result: {result}")
